import cv2
import tkinter as tk
from PIL import Image, ImageTk
from ultralytics import YOLO

model = YOLO('yolov8s.pt')
cap = None  # VideoCapture object

def start_processing():
    global cap
    cap = cv2.VideoCapture(0)
    process_video()

def stop_processing():
    global cap
    cap.release()
    cap = None

def process_video():
    ret, frame = cap.read()
    if ret:
        frame = cv2.resize(frame, (1020, 500))
        results = model.predict(frame, show=True)
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        img = Image.fromarray(frame_rgb)
        img_tk = ImageTk.PhotoImage(img)
        video_label.configure(image=img_tk)
        video_label.image = img_tk
        window.after(1, process_video)
    else:
        stop_processing()

def on_closing():
    if cap is not None:
        stop_processing()
    window.destroy()

window = tk.Tk()
window.title("Video Processing")
window.protocol("WM_DELETE_WINDOW", on_closing)

video_label = tk.Label(window)
video_label.pack()

start_button = tk.Button(window, text="Start", command=start_processing)
start_button.pack(side=tk.LEFT, padx=10, pady=10)

stop_button = tk.Button(window, text="Stop", command=stop_processing)
stop_button.pack(side=tk.LEFT, padx=10, pady=10)

window.mainloop()
